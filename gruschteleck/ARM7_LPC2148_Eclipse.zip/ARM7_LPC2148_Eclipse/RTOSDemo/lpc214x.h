/*****************************************************************************
 *
 * Project          : lwIP Web
 * Subproject       : 
 * Name             : lpc214x.h
 * Function         : register definitions
 * Designer         : K. Sterckx
 * Creation date    : 22/01/2007
 * Compiler         : GNU ARM
 * Processor        : LPC214x
 * Last update      : 2010/10/27
 * Last updated by  : S. Elste
 * History          :
 *
 *****************************************************************************
 *
 * Hardware specific macro's and defines
 *
 ****************************************************************************/

#ifndef __LPC214x_H
#define __LPC214x_H

/* Vectored Interrupt Controller (VIC) */
#define VIC_BASE_ADDR	0xFFFFF000
#define VICIRQStatus   (*(volatile unsigned int *)(VIC_BASE_ADDR + 0x000))
#define VICFIQStatus   (*(volatile unsigned int *)(VIC_BASE_ADDR + 0x004))
#define VICRawIntr     (*(volatile unsigned int *)(VIC_BASE_ADDR + 0x008))
#define VICIntSelect   (*(volatile unsigned int *)(VIC_BASE_ADDR + 0x00C))
#define VICIntEnable   (*(volatile unsigned int *)(VIC_BASE_ADDR + 0x010))
#define VICIntEnClr    (*(volatile unsigned int *)(VIC_BASE_ADDR + 0x014))
#define VICSoftInt     (*(volatile unsigned int *)(VIC_BASE_ADDR + 0x018))
#define VICSoftIntClr  (*(volatile unsigned int *)(VIC_BASE_ADDR + 0x01C))
#define VICProtection  (*(volatile unsigned int *)(VIC_BASE_ADDR + 0x020))
#define VICSWPrioMask  (*(volatile unsigned int *)(VIC_BASE_ADDR + 0x024))

#define VICVectAddr0   (*(volatile unsigned int *)(VIC_BASE_ADDR + 0x100))
#define VICVectAddr1   (*(volatile unsigned int *)(VIC_BASE_ADDR + 0x104))
#define VICVectAddr2   (*(volatile unsigned int *)(VIC_BASE_ADDR + 0x108))
#define VICVectAddr3   (*(volatile unsigned int *)(VIC_BASE_ADDR + 0x10C))
#define VICVectAddr4   (*(volatile unsigned int *)(VIC_BASE_ADDR + 0x110))
#define VICVectAddr5   (*(volatile unsigned int *)(VIC_BASE_ADDR + 0x114))
#define VICVectAddr6   (*(volatile unsigned int *)(VIC_BASE_ADDR + 0x118))
#define VICVectAddr7   (*(volatile unsigned int *)(VIC_BASE_ADDR + 0x11C))
#define VICVectAddr8   (*(volatile unsigned int *)(VIC_BASE_ADDR + 0x120))
#define VICVectAddr9   (*(volatile unsigned int *)(VIC_BASE_ADDR + 0x124))
#define VICVectAddr10  (*(volatile unsigned int *)(VIC_BASE_ADDR + 0x128))
#define VICVectAddr11  (*(volatile unsigned int *)(VIC_BASE_ADDR + 0x12C))
#define VICVectAddr12  (*(volatile unsigned int *)(VIC_BASE_ADDR + 0x130))
#define VICVectAddr13  (*(volatile unsigned int *)(VIC_BASE_ADDR + 0x134))
#define VICVectAddr14  (*(volatile unsigned int *)(VIC_BASE_ADDR + 0x138))
#define VICVectAddr15  (*(volatile unsigned int *)(VIC_BASE_ADDR + 0x13C))

/* The name convention below is from previous LPC2000 family MCUs, in LPC230x,
these registers are known as "VICVectPriority(x)". */
#define VICVectCntl0   (*(volatile unsigned int *)(VIC_BASE_ADDR + 0x200))
#define VICVectCntl1   (*(volatile unsigned int *)(VIC_BASE_ADDR + 0x204))
#define VICVectCntl2   (*(volatile unsigned int *)(VIC_BASE_ADDR + 0x208))
#define VICVectCntl3   (*(volatile unsigned int *)(VIC_BASE_ADDR + 0x20C))
#define VICVectCntl4   (*(volatile unsigned int *)(VIC_BASE_ADDR + 0x210))
#define VICVectCntl5   (*(volatile unsigned int *)(VIC_BASE_ADDR + 0x214))
#define VICVectCntl6   (*(volatile unsigned int *)(VIC_BASE_ADDR + 0x218))
#define VICVectCntl7   (*(volatile unsigned int *)(VIC_BASE_ADDR + 0x21C))
#define VICVectCntl8   (*(volatile unsigned int *)(VIC_BASE_ADDR + 0x220))
#define VICVectCntl9   (*(volatile unsigned int *)(VIC_BASE_ADDR + 0x224))
#define VICVectCntl10  (*(volatile unsigned int *)(VIC_BASE_ADDR + 0x228))
#define VICVectCntl11  (*(volatile unsigned int *)(VIC_BASE_ADDR + 0x22C))
#define VICVectCntl12  (*(volatile unsigned int *)(VIC_BASE_ADDR + 0x230))
#define VICVectCntl13  (*(volatile unsigned int *)(VIC_BASE_ADDR + 0x234))
#define VICVectCntl14  (*(volatile unsigned int *)(VIC_BASE_ADDR + 0x238))
#define VICVectCntl15  (*(volatile unsigned int *)(VIC_BASE_ADDR + 0x23C))

#define VICVectAddr    (*(volatile unsigned int *)(VIC_BASE_ADDR + 0xF00))

/* Pin Connect Block */
#define PINSEL_BASE_ADDR	0xE002C000
#define PINSEL0        (*(volatile unsigned int *)(PINSEL_BASE_ADDR + 0x00))
#define PINSEL1        (*(volatile unsigned int *)(PINSEL_BASE_ADDR + 0x04))
#define PINSEL2        (*(volatile unsigned int *)(PINSEL_BASE_ADDR + 0x08))

/* General Purpose Input/Output (GPIO) */
#define GPIO_BASE_ADDR		0xE0028000
#define IO0PIN         (*(volatile unsigned int *)(GPIO_BASE_ADDR + 0x00))
#define IO0SET         (*(volatile unsigned int *)(GPIO_BASE_ADDR + 0x04))
#define IO0DIR         (*(volatile unsigned int *)(GPIO_BASE_ADDR + 0x08))
#define IO0CLR         (*(volatile unsigned int *)(GPIO_BASE_ADDR + 0x0C))
#define IO1PIN         (*(volatile unsigned int *)(GPIO_BASE_ADDR + 0x10))
#define IO1SET         (*(volatile unsigned int *)(GPIO_BASE_ADDR + 0x14))
#define IO1DIR         (*(volatile unsigned int *)(GPIO_BASE_ADDR + 0x18))
#define IO1CLR         (*(volatile unsigned int *)(GPIO_BASE_ADDR + 0x1C))

/* Fast I/O setup */
#define FIO_BASE_ADDR		0x3FFFC000
#define FIO0DIR        (*(volatile unsigned int *)(FIO_BASE_ADDR + 0x00)) 
#define FIO0MASK       (*(volatile unsigned int *)(FIO_BASE_ADDR + 0x10))
#define FIO0PIN        (*(volatile unsigned int *)(FIO_BASE_ADDR + 0x14))
#define FIO0SET        (*(volatile unsigned int *)(FIO_BASE_ADDR + 0x18))
#define FIO0CLR        (*(volatile unsigned int *)(FIO_BASE_ADDR + 0x1C))

#define FIO1DIR        (*(volatile unsigned int *)(FIO_BASE_ADDR + 0x20)) 
#define FIO1MASK       (*(volatile unsigned int *)(FIO_BASE_ADDR + 0x30))
#define FIO1PIN        (*(volatile unsigned int *)(FIO_BASE_ADDR + 0x34))
#define FIO1SET        (*(volatile unsigned int *)(FIO_BASE_ADDR + 0x38))
#define FIO1CLR        (*(volatile unsigned int *)(FIO_BASE_ADDR + 0x3C))

/* FIOs can be accessed through WORD, HALF-WORD or BYTE. */
#define FIO0DIR0       (*(volatile unsigned char  *)(FIO_BASE_ADDR + 0x01)) 
#define FIO1DIR0       (*(volatile unsigned char  *)(FIO_BASE_ADDR + 0x21)) 

#define FIO0DIR1       (*(volatile unsigned char  *)(FIO_BASE_ADDR + 0x02)) 
#define FIO1DIR1       (*(volatile unsigned char  *)(FIO_BASE_ADDR + 0x22)) 

#define FIO0DIR2       (*(volatile unsigned char  *)(FIO_BASE_ADDR + 0x03)) 
#define FIO1DIR2       (*(volatile unsigned char  *)(FIO_BASE_ADDR + 0x23)) 

#define FIO0DIR3       (*(volatile unsigned char  *)(FIO_BASE_ADDR + 0x04)) 
#define FIO1DIR3       (*(volatile unsigned char  *)(FIO_BASE_ADDR + 0x24)) 

#define FIO0DIRL       (*(volatile unsigned short *)(FIO_BASE_ADDR + 0x00)) 
#define FIO1DIRL       (*(volatile unsigned short *)(FIO_BASE_ADDR + 0x20)) 

#define FIO0DIRU       (*(volatile unsigned short *)(FIO_BASE_ADDR + 0x02)) 
#define FIO1DIRU       (*(volatile unsigned short *)(FIO_BASE_ADDR + 0x22)) 

#define FIO0MASK0      (*(volatile unsigned char  *)(FIO_BASE_ADDR + 0x10)) 
#define FIO1MASK0      (*(volatile unsigned char  *)(FIO_BASE_ADDR + 0x30)) 

#define FIO0MASK1      (*(volatile unsigned char  *)(FIO_BASE_ADDR + 0x11)) 
#define FIO1MASK1      (*(volatile unsigned char  *)(FIO_BASE_ADDR + 0x21)) 

#define FIO0MASK2      (*(volatile unsigned char  *)(FIO_BASE_ADDR + 0x12)) 
#define FIO1MASK2      (*(volatile unsigned char  *)(FIO_BASE_ADDR + 0x32)) 

#define FIO0MASK3      (*(volatile unsigned char  *)(FIO_BASE_ADDR + 0x13)) 
#define FIO1MASK3      (*(volatile unsigned char  *)(FIO_BASE_ADDR + 0x33)) 

#define FIO0MASKL      (*(volatile unsigned short *)(FIO_BASE_ADDR + 0x10)) 
#define FIO1MASKL      (*(volatile unsigned short *)(FIO_BASE_ADDR + 0x30)) 

#define FIO0MASKU      (*(volatile unsigned short *)(FIO_BASE_ADDR + 0x12)) 
#define FIO1MASKU      (*(volatile unsigned short *)(FIO_BASE_ADDR + 0x32)) 

#define FIO0PIN0       (*(volatile unsigned char  *)(FIO_BASE_ADDR + 0x14)) 
#define FIO1PIN0       (*(volatile unsigned char  *)(FIO_BASE_ADDR + 0x34)) 

#define FIO0PIN1       (*(volatile unsigned char  *)(FIO_BASE_ADDR + 0x15)) 
#define FIO1PIN1       (*(volatile unsigned char  *)(FIO_BASE_ADDR + 0x25)) 

#define FIO0PIN2       (*(volatile unsigned char  *)(FIO_BASE_ADDR + 0x16)) 
#define FIO1PIN2       (*(volatile unsigned char  *)(FIO_BASE_ADDR + 0x36)) 

#define FIO0PIN3       (*(volatile unsigned char  *)(FIO_BASE_ADDR + 0x17)) 
#define FIO1PIN3       (*(volatile unsigned char  *)(FIO_BASE_ADDR + 0x37)) 

#define FIO0PINL       (*(volatile unsigned short *)(FIO_BASE_ADDR + 0x14)) 
#define FIO1PINL       (*(volatile unsigned short *)(FIO_BASE_ADDR + 0x34)) 

#define FIO0PINU       (*(volatile unsigned short *)(FIO_BASE_ADDR + 0x16)) 
#define FIO1PINU       (*(volatile unsigned short *)(FIO_BASE_ADDR + 0x36)) 

#define FIO0SET0       (*(volatile unsigned char  *)(FIO_BASE_ADDR + 0x18)) 
#define FIO1SET0       (*(volatile unsigned char  *)(FIO_BASE_ADDR + 0x38)) 

#define FIO0SET1       (*(volatile unsigned char  *)(FIO_BASE_ADDR + 0x19)) 
#define FIO1SET1       (*(volatile unsigned char  *)(FIO_BASE_ADDR + 0x29)) 

#define FIO0SET2       (*(volatile unsigned char  *)(FIO_BASE_ADDR + 0x1A)) 
#define FIO1SET2       (*(volatile unsigned char  *)(FIO_BASE_ADDR + 0x3A)) 

#define FIO0SET3       (*(volatile unsigned char  *)(FIO_BASE_ADDR + 0x1B)) 
#define FIO1SET3       (*(volatile unsigned char  *)(FIO_BASE_ADDR + 0x3B)) 

#define FIO0SETL       (*(volatile unsigned short *)(FIO_BASE_ADDR + 0x18)) 
#define FIO1SETL       (*(volatile unsigned short *)(FIO_BASE_ADDR + 0x38)) 

#define FIO0SETU       (*(volatile unsigned short *)(FIO_BASE_ADDR + 0x1A)) 
#define FIO1SETU       (*(volatile unsigned short *)(FIO_BASE_ADDR + 0x3A)) 

#define FIO0CLR0       (*(volatile unsigned char  *)(FIO_BASE_ADDR + 0x1C)) 
#define FIO1CLR0       (*(volatile unsigned char  *)(FIO_BASE_ADDR + 0x3C)) 

#define FIO0CLR1       (*(volatile unsigned char  *)(FIO_BASE_ADDR + 0x1D)) 
#define FIO1CLR1       (*(volatile unsigned char  *)(FIO_BASE_ADDR + 0x2D)) 

#define FIO0CLR2       (*(volatile unsigned char  *)(FIO_BASE_ADDR + 0x1E)) 
#define FIO1CLR2       (*(volatile unsigned char  *)(FIO_BASE_ADDR + 0x3E)) 

#define FIO0CLR3       (*(volatile unsigned char  *)(FIO_BASE_ADDR + 0x1F)) 
#define FIO1CLR3       (*(volatile unsigned char  *)(FIO_BASE_ADDR + 0x3F)) 

#define FIO0CLRL       (*(volatile unsigned short *)(FIO_BASE_ADDR + 0x1C)) 
#define FIO1CLRL       (*(volatile unsigned short *)(FIO_BASE_ADDR + 0x3C)) 

#define FIO0CLRU       (*(volatile unsigned short *)(FIO_BASE_ADDR + 0x1E)) 
#define FIO1CLRU       (*(volatile unsigned short *)(FIO_BASE_ADDR + 0x3E)) 

/* System Control Block(SCB) modules include Memory Accelerator Module,
Phase Locked Loop, VPB divider, Power Control, External Interrupt, 
Reset, and Code Security/Debugging */
#define SCB_BASE_ADDR	0xE01FC000

/* Memory Accelerator Module (MAM) */
#define MAMCR          (*(volatile unsigned int *)(SCB_BASE_ADDR + 0x000))
#define MAMTIM         (*(volatile unsigned int *)(SCB_BASE_ADDR + 0x004))

/* Phase Locked Loop (PLL) */
#define PLL0CON         (*(volatile unsigned int *)(SCB_BASE_ADDR + 0x080))
#define PLL0CFG         (*(volatile unsigned int *)(SCB_BASE_ADDR + 0x084))
#define PLL0STAT        (*(volatile unsigned int *)(SCB_BASE_ADDR + 0x088))
#define PLL0FEED        (*(volatile unsigned int *)(SCB_BASE_ADDR + 0x08C))
#define PLL1CON         (*(volatile unsigned int *)(SCB_BASE_ADDR + 0x0A0))
#define PLL1CFG         (*(volatile unsigned int *)(SCB_BASE_ADDR + 0x0A4))
#define PLL1STAT        (*(volatile unsigned int *)(SCB_BASE_ADDR + 0x0A8))
#define PLL1FEED        (*(volatile unsigned int *)(SCB_BASE_ADDR + 0x0AC))

/* Power Control */
#define PCON			(*(volatile unsigned int *)(SCB_BASE_ADDR + 0x0C0))
#define PCONP			(*(volatile unsigned int *)(SCB_BASE_ADDR + 0x0C4))

/* VPB Divider */
#define VPBDIV			(*(volatile unsigned int *)(SCB_BASE_ADDR + 0x100))

/* External Interrupts */
#define EXTINT         (*(volatile unsigned int *)(SCB_BASE_ADDR + 0x140))
#define INTWAKE        (*(volatile unsigned int *)(SCB_BASE_ADDR + 0x144))
#define EXTMODE        (*(volatile unsigned int *)(SCB_BASE_ADDR + 0x148))
#define EXTPOLAR       (*(volatile unsigned int *)(SCB_BASE_ADDR + 0x14C))

/* Reset, reset source identification */
#define RSID           (*(volatile unsigned int *)(SCB_BASE_ADDR + 0x180))

/* RSID, code security protection */
#define CSPR           (*(volatile unsigned int *)(SCB_BASE_ADDR + 0x184))

/* System Controls and Status */
#define SCS            (*(volatile unsigned int *)(SCB_BASE_ADDR + 0x1A0))
	
/* Timer 0 */
#define TMR0_BASE_ADDR		0xE0004000
#define T0IR			(*(volatile unsigned int *)(TMR0_BASE_ADDR + 0x00))
#define T0TCR			(*(volatile unsigned int *)(TMR0_BASE_ADDR + 0x04))
#define T0TC			(*(volatile unsigned int *)(TMR0_BASE_ADDR + 0x08))
#define T0PR			(*(volatile unsigned int *)(TMR0_BASE_ADDR + 0x0C))
#define T0PC			(*(volatile unsigned int *)(TMR0_BASE_ADDR + 0x10))
#define T0MCR			(*(volatile unsigned int *)(TMR0_BASE_ADDR + 0x14))
#define T0MR0			(*(volatile unsigned int *)(TMR0_BASE_ADDR + 0x18))
#define T0MR1			(*(volatile unsigned int *)(TMR0_BASE_ADDR + 0x1C))
#define T0MR2			(*(volatile unsigned int *)(TMR0_BASE_ADDR + 0x20))
#define T0MR3			(*(volatile unsigned int *)(TMR0_BASE_ADDR + 0x24))
#define T0CCR			(*(volatile unsigned int *)(TMR0_BASE_ADDR + 0x28))
#define T0CR0			(*(volatile unsigned int *)(TMR0_BASE_ADDR + 0x2C))
#define T0CR1			(*(volatile unsigned int *)(TMR0_BASE_ADDR + 0x30))
#define T0CR2			(*(volatile unsigned int *)(TMR0_BASE_ADDR + 0x34))
#define T0CR3			(*(volatile unsigned int *)(TMR0_BASE_ADDR + 0x38))
#define T0EMR			(*(volatile unsigned int *)(TMR0_BASE_ADDR + 0x3C))
#define T0CTCR			(*(volatile unsigned int *)(TMR0_BASE_ADDR + 0x70))

/* Timer 1 */
#define TMR1_BASE_ADDR		0xE0008000
#define T1IR			(*(volatile unsigned int *)(TMR1_BASE_ADDR + 0x00))
#define T1TCR			(*(volatile unsigned int *)(TMR1_BASE_ADDR + 0x04))
#define T1TC			(*(volatile unsigned int *)(TMR1_BASE_ADDR + 0x08))
#define T1PR			(*(volatile unsigned int *)(TMR1_BASE_ADDR + 0x0C))
#define T1PC			(*(volatile unsigned int *)(TMR1_BASE_ADDR + 0x10))
#define T1MCR			(*(volatile unsigned int *)(TMR1_BASE_ADDR + 0x14))
#define T1MR0			(*(volatile unsigned int *)(TMR1_BASE_ADDR + 0x18))
#define T1MR1			(*(volatile unsigned int *)(TMR1_BASE_ADDR + 0x1C))
#define T1MR2			(*(volatile unsigned int *)(TMR1_BASE_ADDR + 0x20))
#define T1MR3			(*(volatile unsigned int *)(TMR1_BASE_ADDR + 0x24))
#define T1CCR			(*(volatile unsigned int *)(TMR1_BASE_ADDR + 0x28))
#define T1CR0			(*(volatile unsigned int *)(TMR1_BASE_ADDR + 0x2C))
#define T1CR1			(*(volatile unsigned int *)(TMR1_BASE_ADDR + 0x30))
#define T1CR2			(*(volatile unsigned int *)(TMR1_BASE_ADDR + 0x34))
#define T1CR3			(*(volatile unsigned int *)(TMR1_BASE_ADDR + 0x38))
#define T1EMR			(*(volatile unsigned int *)(TMR1_BASE_ADDR + 0x3C))
#define T1CTCR			(*(volatile unsigned int *)(TMR1_BASE_ADDR + 0x70))

/* Pulse Width Modulator (PWM) */
#define PWM_BASE_ADDR		0xE0014000
#define PWMIR			(*(volatile unsigned int *)(PWM_BASE_ADDR + 0x00))
#define PWMTCR			(*(volatile unsigned int *)(PWM_BASE_ADDR + 0x04))
#define PWMTC			(*(volatile unsigned int *)(PWM_BASE_ADDR + 0x08))
#define PWMPR			(*(volatile unsigned int *)(PWM_BASE_ADDR + 0x0C))
#define PWMPC			(*(volatile unsigned int *)(PWM_BASE_ADDR + 0x10))
#define PWMMCR			(*(volatile unsigned int *)(PWM_BASE_ADDR + 0x14))
#define PWMMR0			(*(volatile unsigned int *)(PWM_BASE_ADDR + 0x18))
#define PWMMR1			(*(volatile unsigned int *)(PWM_BASE_ADDR + 0x1C))
#define PWMMR2			(*(volatile unsigned int *)(PWM_BASE_ADDR + 0x20))
#define PWMMR3			(*(volatile unsigned int *)(PWM_BASE_ADDR + 0x24))
#define PWMCCR			(*(volatile unsigned int *)(PWM_BASE_ADDR + 0x28))
#define PWMCR0			(*(volatile unsigned int *)(PWM_BASE_ADDR + 0x2C))
#define PWMCR1			(*(volatile unsigned int *)(PWM_BASE_ADDR + 0x30))
#define PWMCR2			(*(volatile unsigned int *)(PWM_BASE_ADDR + 0x34))
#define PWMCR3			(*(volatile unsigned int *)(PWM_BASE_ADDR + 0x38))
#define PWMEMR			(*(volatile unsigned int *)(PWM_BASE_ADDR + 0x3C))
#define PWMMR4			(*(volatile unsigned int *)(PWM_BASE_ADDR + 0x40))
#define PWMMR5			(*(volatile unsigned int *)(PWM_BASE_ADDR + 0x44))
#define PWMMR6			(*(volatile unsigned int *)(PWM_BASE_ADDR + 0x48))
#define PWMPCR			(*(volatile unsigned int *)(PWM_BASE_ADDR + 0x4C))
#define PWMLER			(*(volatile unsigned int *)(PWM_BASE_ADDR + 0x50))
#define PWMCTCR			(*(volatile unsigned int *)(PWM_BASE_ADDR + 0x70))

/* Universal Asynchronous Receiver Transmitter 0 (UART0) */
#define UART0_BASE_ADDR		0xE000C000
#define U0RBR			(*(volatile unsigned int *)(UART0_BASE_ADDR + 0x00))
#define U0THR			(*(volatile unsigned int *)(UART0_BASE_ADDR + 0x00))
#define U0DLL			(*(volatile unsigned int *)(UART0_BASE_ADDR + 0x00))
#define U0DLM			(*(volatile unsigned int *)(UART0_BASE_ADDR + 0x04))
#define U0IER			(*(volatile unsigned int *)(UART0_BASE_ADDR + 0x04))
#define U0IIR			(*(volatile unsigned int *)(UART0_BASE_ADDR + 0x08))
#define U0FCR			(*(volatile unsigned int *)(UART0_BASE_ADDR + 0x08))
#define U0LCR			(*(volatile unsigned int *)(UART0_BASE_ADDR + 0x0C))
#define U0LSR			(*(volatile unsigned int *)(UART0_BASE_ADDR + 0x14))
#define U0SCR			(*(volatile unsigned int *)(UART0_BASE_ADDR + 0x1C))
#define U0ACR			(*(volatile unsigned int *)(UART0_BASE_ADDR + 0x20))
#define U0ICR			(*(volatile unsigned int *)(UART0_BASE_ADDR + 0x24))
#define U0FDR			(*(volatile unsigned int *)(UART0_BASE_ADDR + 0x28))
#define U0TER			(*(volatile unsigned int *)(UART0_BASE_ADDR + 0x30))

/* Universal Asynchronous Receiver Transmitter 1 (UART1) */
#define UART1_BASE_ADDR		0xE0010000
#define U1RBR			(*(volatile unsigned int *)(UART1_BASE_ADDR + 0x00))
#define U1THR			(*(volatile unsigned int *)(UART1_BASE_ADDR + 0x00))
#define U1DLL			(*(volatile unsigned int *)(UART1_BASE_ADDR + 0x00))
#define U1DLM			(*(volatile unsigned int *)(UART1_BASE_ADDR + 0x04))
#define U1IER			(*(volatile unsigned int *)(UART1_BASE_ADDR + 0x04))
#define U1IIR			(*(volatile unsigned int *)(UART1_BASE_ADDR + 0x08))
#define U1FCR			(*(volatile unsigned int *)(UART1_BASE_ADDR + 0x08))
#define U1LCR			(*(volatile unsigned int *)(UART1_BASE_ADDR + 0x0C))
#define U1MCR			(*(volatile unsigned int *)(UART1_BASE_ADDR + 0x10))
#define U1LSR			(*(volatile unsigned int *)(UART1_BASE_ADDR + 0x14))
#define U1MSR			(*(volatile unsigned int *)(UART1_BASE_ADDR + 0x18))
#define U1SCR			(*(volatile unsigned int *)(UART1_BASE_ADDR + 0x1C))
#define U1ACR			(*(volatile unsigned int *)(UART1_BASE_ADDR + 0x20))
#define U1FDR			(*(volatile unsigned int *)(UART1_BASE_ADDR + 0x28))
#define U1TER			(*(volatile unsigned int *)(UART1_BASE_ADDR + 0x30))

/* I2C Interface 0 */
#define I2C0_BASE_ADDR		0xE001C000
#define I2C0CONSET      (*(volatile unsigned int *)(I2C0_BASE_ADDR + 0x00))
#define I2C0STAT        (*(volatile unsigned int *)(I2C0_BASE_ADDR + 0x04))
#define I2C0DAT         (*(volatile unsigned int *)(I2C0_BASE_ADDR + 0x08))
#define I2C0ADR         (*(volatile unsigned int *)(I2C0_BASE_ADDR + 0x0C))
#define I2C0SCLH        (*(volatile unsigned int *)(I2C0_BASE_ADDR + 0x10))
#define I2C0SCLL        (*(volatile unsigned int *)(I2C0_BASE_ADDR + 0x14))
#define I2C0CONCLR      (*(volatile unsigned int *)(I2C0_BASE_ADDR + 0x18))

/* I2C Interface 1 */
#define I2C1_BASE_ADDR		0xE005C000
#define I2C1CONSET      (*(volatile unsigned int *)(I2C1_BASE_ADDR + 0x00))
#define I2C1STAT        (*(volatile unsigned int *)(I2C1_BASE_ADDR + 0x04))
#define I2C1DAT         (*(volatile unsigned int *)(I2C1_BASE_ADDR + 0x08))
#define I2C1ADR         (*(volatile unsigned int *)(I2C1_BASE_ADDR + 0x0C))
#define I2C1SCLH        (*(volatile unsigned int *)(I2C1_BASE_ADDR + 0x10))
#define I2C1SCLL        (*(volatile unsigned int *)(I2C1_BASE_ADDR + 0x14))
#define I2C1CONCLR      (*(volatile unsigned int *)(I2C1_BASE_ADDR + 0x18))

/* SPI0 (Serial Peripheral Interface 0) */
#define SPI0_BASE_ADDR		0xE0020000
#define S0SPCR			(*(volatile unsigned int *)(SPI0_BASE_ADDR + 0x00))
#define S0SPSR			(*(volatile unsigned int *)(SPI0_BASE_ADDR + 0x04))
#define S0SPDR			(*(volatile unsigned int *)(SPI0_BASE_ADDR + 0x08))
#define S0SPCCR			(*(volatile unsigned int *)(SPI0_BASE_ADDR + 0x0C))
#define S0SPINT			(*(volatile unsigned int *)(SPI0_BASE_ADDR + 0x1C))

/* SSP Controller */
#define SSP_BASE_ADDR		0xE0068000
#define SSPCR0			(*(volatile unsigned int *)(SSP0_BASE_ADDR + 0x00))
#define SSPCR1			(*(volatile unsigned int *)(SSP0_BASE_ADDR + 0x04))
#define SSPDR			(*(volatile unsigned int *)(SSP0_BASE_ADDR + 0x08))
#define SSPSR			(*(volatile unsigned int *)(SSP0_BASE_ADDR + 0x0C))
#define SSPCPSR			(*(volatile unsigned int *)(SSP0_BASE_ADDR + 0x10))
#define SSPIMSC			(*(volatile unsigned int *)(SSP0_BASE_ADDR + 0x14))
#define SSPRIS			(*(volatile unsigned int *)(SSP0_BASE_ADDR + 0x18))
#define SSPMIS			(*(volatile unsigned int *)(SSP0_BASE_ADDR + 0x1C))
#define SSPICR			(*(volatile unsigned int *)(SSP0_BASE_ADDR + 0x20))
#define SSPDMACR		(*(volatile unsigned int *)(SSP0_BASE_ADDR + 0x24))

/* Real Time Clock */
#define RTC_BASE_ADDR		0xE0024000
#define RTC_ILR         (*(volatile unsigned int *)(RTC_BASE_ADDR + 0x00))
#define RTC_CTC         (*(volatile unsigned int *)(RTC_BASE_ADDR + 0x04))
#define RTC_CCR         (*(volatile unsigned int *)(RTC_BASE_ADDR + 0x08))
#define RTC_CIIR        (*(volatile unsigned int *)(RTC_BASE_ADDR + 0x0C))
#define RTC_AMR         (*(volatile unsigned int *)(RTC_BASE_ADDR + 0x10))
#define RTC_CTIME0      (*(volatile unsigned int *)(RTC_BASE_ADDR + 0x14))
#define RTC_CTIME1      (*(volatile unsigned int *)(RTC_BASE_ADDR + 0x18))
#define RTC_CTIME2      (*(volatile unsigned int *)(RTC_BASE_ADDR + 0x1C))
#define RTC_SEC         (*(volatile unsigned int *)(RTC_BASE_ADDR + 0x20))
#define RTC_MIN         (*(volatile unsigned int *)(RTC_BASE_ADDR + 0x24))
#define RTC_HOUR        (*(volatile unsigned int *)(RTC_BASE_ADDR + 0x28))
#define RTC_DOM         (*(volatile unsigned int *)(RTC_BASE_ADDR + 0x2C))
#define RTC_DOW         (*(volatile unsigned int *)(RTC_BASE_ADDR + 0x30))
#define RTC_DOY         (*(volatile unsigned int *)(RTC_BASE_ADDR + 0x34))
#define RTC_MONTH       (*(volatile unsigned int *)(RTC_BASE_ADDR + 0x38))
#define RTC_YEAR        (*(volatile unsigned int *)(RTC_BASE_ADDR + 0x3C))
#define RTC_CISS        (*(volatile unsigned int *)(RTC_BASE_ADDR + 0x40))
#define RTC_ALSEC       (*(volatile unsigned int *)(RTC_BASE_ADDR + 0x60))
#define RTC_ALMIN       (*(volatile unsigned int *)(RTC_BASE_ADDR + 0x64))
#define RTC_ALHOUR      (*(volatile unsigned int *)(RTC_BASE_ADDR + 0x68))
#define RTC_ALDOM       (*(volatile unsigned int *)(RTC_BASE_ADDR + 0x6C))
#define RTC_ALDOW       (*(volatile unsigned int *)(RTC_BASE_ADDR + 0x70))
#define RTC_ALDOY       (*(volatile unsigned int *)(RTC_BASE_ADDR + 0x74))
#define RTC_ALMON       (*(volatile unsigned int *)(RTC_BASE_ADDR + 0x78))
#define RTC_ALYEAR      (*(volatile unsigned int *)(RTC_BASE_ADDR + 0x7C))
#define RTC_PREINT      (*(volatile unsigned int *)(RTC_BASE_ADDR + 0x80))
#define RTC_PREFRAC     (*(volatile unsigned int *)(RTC_BASE_ADDR + 0x84))

/* A/D Converter 0 (AD0) */
#define AD0_BASE_ADDR		0xE0034000
#define AD0CR			(*(volatile unsigned int *)(AD0_BASE_ADDR + 0x00))
#define AD0GDR			(*(volatile unsigned int *)(AD0_BASE_ADDR + 0x04))
#define AD0INTEN		(*(volatile unsigned int *)(AD0_BASE_ADDR + 0x0C))
#define AD0DR0			(*(volatile unsigned int *)(AD0_BASE_ADDR + 0x10))
#define AD0DR1			(*(volatile unsigned int *)(AD0_BASE_ADDR + 0x14))
#define AD0DR2			(*(volatile unsigned int *)(AD0_BASE_ADDR + 0x18))
#define AD0DR3			(*(volatile unsigned int *)(AD0_BASE_ADDR + 0x1C))
#define AD0DR4			(*(volatile unsigned int *)(AD0_BASE_ADDR + 0x20))
#define AD0DR5			(*(volatile unsigned int *)(AD0_BASE_ADDR + 0x24))
#define AD0DR6			(*(volatile unsigned int *)(AD0_BASE_ADDR + 0x28))
#define AD0DR7			(*(volatile unsigned int *)(AD0_BASE_ADDR + 0x2C))
#define AD0STAT			(*(volatile unsigned int *)(AD0_BASE_ADDR + 0x30))

/* A/D Converter 1 (AD1) */
#define AD1_BASE_ADDR		0xE0036000
#define AD1CR			(*(volatile unsigned int *)(AD1_BASE_ADDR + 0x00))
#define AD1GDR			(*(volatile unsigned int *)(AD1_BASE_ADDR + 0x04))
#define AD1INTEN		(*(volatile unsigned int *)(AD1_BASE_ADDR + 0x0C))
#define AD1DR0			(*(volatile unsigned int *)(AD1_BASE_ADDR + 0x10))
#define AD1DR1			(*(volatile unsigned int *)(AD1_BASE_ADDR + 0x14))
#define AD1DR2			(*(volatile unsigned int *)(AD1_BASE_ADDR + 0x18))
#define AD1DR3			(*(volatile unsigned int *)(AD1_BASE_ADDR + 0x1C))
#define AD1DR4			(*(volatile unsigned int *)(AD1_BASE_ADDR + 0x20))
#define AD1DR5			(*(volatile unsigned int *)(AD1_BASE_ADDR + 0x24))
#define AD1DR6			(*(volatile unsigned int *)(AD1_BASE_ADDR + 0x28))
#define AD1DR7			(*(volatile unsigned int *)(AD1_BASE_ADDR + 0x2C))
#define AD1STAT			(*(volatile unsigned int *)(AD1_BASE_ADDR + 0x30))

/* D/A Converter */
#define DAC_BASE_ADDR		0xE006C000
#define DACR           (*(volatile unsigned int *)(DAC_BASE_ADDR + 0x00))

/* Watchdog */
#define WDG_BASE_ADDR		0xE0000000
#define WDMOD          (*(volatile unsigned int *)(WDG_BASE_ADDR + 0x00))
#define WDTC           (*(volatile unsigned int *)(WDG_BASE_ADDR + 0x04))
#define WDFEED         (*(volatile unsigned int *)(WDG_BASE_ADDR + 0x08))
#define WDTV           (*(volatile unsigned int *)(WDG_BASE_ADDR + 0x0C))
#define WDCLKSEL       (*(volatile unsigned int *)(WDG_BASE_ADDR + 0x10))


#endif  /* __LPC214x_H */

